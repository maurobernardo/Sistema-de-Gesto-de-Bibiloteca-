package model;

public class Pesquisa {
    private String termoBusca;

    // Construtor
    public Pesquisa(String termoBusca) {
        this.termoBusca = termoBusca;
    }

    // Getter e setter
    public String getTermoBusca() {
        return termoBusca;
    }

    public void setTermoBusca(String termoBusca) {
        this.termoBusca = termoBusca;
    }
}
