package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TelaInicialGUI extends JFrame {
    private JButton loginButton;

    public TelaInicialGUI() {
        setTitle("Sistema de Biblioteca");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout()); 
        panel.setBackground(new Color(245, 245, 245)); 
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 0, 10, 0);

        // Título
        JLabel titulo = new JLabel("Bem-vindo ao Sistema de Biblioteca", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        titulo.setForeground(new Color(0, 51, 102));  // Cor azul mais suave
        panel.add(titulo, gbc);

        // Lema
        gbc.gridy = 1;
        JLabel lema = new JLabel("Inspire-se. Descubra-se: O Conhecimento Espera por Voce.", JLabel.CENTER);
        lema.setFont(new Font("Arial", Font.ITALIC, 16
        ));
        lema.setForeground(new Color(0, 102, 204));  // Cor mais suave para o lema
        panel.add(lema, gbc);

        // Botão de login
        gbc.gridy = 2;
        loginButton = new JButton("Aceder ao Sistema");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setBackground(new Color(0, 123, 255));  // Azul
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setPreferredSize(new Dimension(200, 40));

        panel.add(loginButton, gbc);

        add(panel, BorderLayout.CENTER); 
        // Ação ao clicar no botão de login
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginGUI().setVisible(true); 
                dispose(); 
            }
        });

        setLocationRelativeTo(null);  
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TelaInicialGUI().setVisible(true));  
    }
}
