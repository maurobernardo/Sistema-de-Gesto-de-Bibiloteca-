package gui;

import model.Livro;
import dao.LivroDAO;
import db.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class BuscarLivrosGUI extends JFrame {
    private JTextField buscaField;
    private JButton buscarButton, listarButton, voltarButton;
    private JTable livrosTable;
    private DefaultTableModel tableModel;
    private LivroDAO livroDAO;

    public BuscarLivrosGUI() {
        try {
            this.livroDAO = new LivroDAO(DatabaseConnection.getConnection());  // Obter a conexão real com o DB
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar com o banco de dados.");
            return;
        }

        setTitle("Buscar Livros - Sistema de Biblioteca");
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));  // Usando BorderLayout para melhor organização
        getContentPane().setBackground(new Color(245, 245, 245));  // Cor de fundo similar

        // Painel de busca com FlowLayout
        JPanel buscaPanel = new JPanel();
        buscaPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));  // FlowLayout para centralizar os componentes
        buscaPanel.setBackground(new Color(245, 245, 245));

        buscaField = new JTextField(20);
        buscarButton = new JButton("Buscar");
        listarButton = new JButton("Listar Todos os Livros");
        voltarButton = new JButton("Voltar");

        // Adicionando os componentes ao painel de busca
        buscaPanel.add(new JLabel("Buscar por título, autor ou categoria:"));
        buscaPanel.add(buscaField);
        buscaPanel.add(buscarButton);
        buscaPanel.add(listarButton);
        buscaPanel.add(voltarButton);

        // Configuração da tabela para exibir resultados
        tableModel = new DefaultTableModel(new Object[][]{}, new String[]{"Título", "Autor", "Ano", "Categoria", "ISBN"});
        livrosTable = new JTable(tableModel);
        livrosTable.setFillsViewportHeight(true);  // A tabela ocupa toda a altura disponível

        JScrollPane scrollPane = new JScrollPane(livrosTable);

        // Painel de botões
        JPanel botoesPanel = new JPanel();
        botoesPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));  // FlowLayout com centralização
        botoesPanel.setBackground(new Color(245, 245, 245));

        // Estilizando os botões
        configurarBotao(buscarButton);
        configurarBotao(listarButton);
        configurarBotao(voltarButton);

        // Adicionando os botões ao painel de botões
        botoesPanel.add(buscarButton);
        botoesPanel.add(listarButton);
        botoesPanel.add(voltarButton);

        // Adicionando os componentes à janela principal
        add(buscaPanel, BorderLayout.NORTH);  // Coloca o painel de busca no topo
        add(scrollPane, BorderLayout.CENTER);  // Coloca a tabela de resultados no centro
        add(botoesPanel, BorderLayout.SOUTH);  // Coloca os botões na parte inferior

        // Ação do botão Buscar
        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String termo = buscaField.getText();
                try {
                    List<Livro> livros = livroDAO.buscarLivros(termo);
                    tableModel.setRowCount(0);  // Limpa as linhas da tabela
                    for (Livro livro : livros) {
                        tableModel.addRow(new Object[]{livro.getTitulo(), livro.getAutor(), livro.getAnoPublicacao(), livro.getCategoria(), livro.getIsbn()});
                    }
                    if (livros.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Nenhum livro encontrado.");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Erro ao buscar livros.");
                }
            }
        });

        // Ação do botão Listar Todos os Livros
        listarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarTodosLivros();
            }
        });

        // Ação do botão Voltar
        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                voltarTelaLogin();
            }
        });

        setLocationRelativeTo(null);  // Centraliza a janela
    }

    // Método para listar todos os livros com mais detalhes na tabela
    private void listarTodosLivros() {
        try {
            List<Livro> livros = livroDAO.listarLivros();
            tableModel.setRowCount(0);  // Limpa as linhas da tabela
            for (Livro livro : livros) {
                tableModel.addRow(new Object[]{livro.getTitulo(), livro.getAutor(), livro.getAnoPublicacao(), livro.getCategoria(), livro.getIsbn()});
            }
            if (livros.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nenhum livro cadastrado.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao listar livros.");
        }
    }

    // Método para voltar para a tela de login
    private void voltarTelaLogin() {
        this.dispose();  // Fecha a tela atual
        new LoginGUI().setVisible(true);  // Abre a tela de login
    }

    private void configurarBotao(JButton botao) {
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setBackground(new Color(0, 122, 204));
        botao.setForeground(Color.WHITE);
        botao.setPreferredSize(new Dimension(140, 35));  // Tamanho compacto
        botao.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        botao.setFocusPainted(false);
        botao.setOpaque(true);

        // Efeito de hover nos botões
        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botao.setBackground(new Color(0, 150, 255));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botao.setBackground(new Color(0, 122, 204));
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BuscarLivrosGUI().setVisible(true));  // Chama o construtor sem passar o DAO, que já é instanciado no BuscarLivrosGUI
    }
}
