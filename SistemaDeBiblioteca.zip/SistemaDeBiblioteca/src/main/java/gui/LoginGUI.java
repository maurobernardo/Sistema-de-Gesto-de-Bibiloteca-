package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import dao.UsuarioDAO;
import model.Usuario;
import db.DatabaseConnection;
import java.sql.*;

public class LoginGUI extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginButton, registerButton, backButton;
    
    private UsuarioDAO usuarioDAO;

    public LoginGUI() {
        // Conectar ao banco de dados
        try {
            Connection connection = DatabaseConnection.getConnection();
            usuarioDAO = new UsuarioDAO(connection);  // Inicializa o DAO de Usuário
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados.");
        }

        setTitle("Login - Sistema de Biblioteca");
        setSize(400, 400); // Ajuste o tamanho conforme necessário
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Definindo o fundo cinza para a janela
        getContentPane().setBackground(new Color(211, 211, 211)); // Cor de fundo cinza claro
        
        // Criar painel para os campos de login
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridBagLayout());
        loginPanel.setBackground(new Color(211, 211, 211)); // Cor de fundo cinza claro para o painel de login
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10); // Espaçamento entre os componentes
        gbc.anchor = GridBagConstraints.CENTER; // Centralizando os componentes
        
        // E-mail
        JLabel emailLabel = new JLabel("E-mail:");
        emailField = new JTextField(20);
        emailField.setPreferredSize(new Dimension(250, 30));
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        emailField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        
        // Senha
        JLabel senhaLabel = new JLabel("Senha:");
        passwordField = new JPasswordField(20);
        passwordField.setPreferredSize(new Dimension(250, 30));
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        
        // Botões de login
        loginButton = new JButton("Login");
        registerButton = new JButton("Registrar-se");
        backButton = new JButton("Voltar");
        
        // Estilo dos botões
        Font buttonFont = new Font("Arial", Font.BOLD, 16);
        Color buttonColor = new Color(0, 122, 204); // Azul para o botão
        Color hoverColor = new Color(0, 150, 255); // Azul mais claro quando passar o mouse
        
        // Configuração dos botões
        configurarBotao(loginButton, buttonFont, buttonColor, hoverColor);
        configurarBotao(registerButton, buttonFont, buttonColor, hoverColor);
        configurarBotao(backButton, buttonFont, buttonColor, hoverColor);
        
        // Ações dos botões
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText();
                String senha = new String(passwordField.getPassword());
        
                // Verificação para garantir que os campos não estão vazios
                if (email.isEmpty() || senha.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.");
                    return; // Interrompe o processo se algum campo estiver vazio
                }
                
                // Verifica as credenciais e o tipo de usuário
                try {
                    Usuario usuario = usuarioDAO.autenticarUsuario(email, senha);
                    
                    if (usuario != null) {
                        JOptionPane.showMessageDialog(null, "Login realizado com sucesso!");
                        
                        // Lógica de abrir as telas de acordo com o tipo de usuário
                        if (usuario.getTipoUsuario().equalsIgnoreCase("funcionario")) {
                            // Funcionário - abre a tela de Gerenciamento de Livros
                            new GerenciarLivrosGUI().setVisible(true);
                        } else if (usuario.getTipoUsuario().equalsIgnoreCase("estudante")) {
                            // Estudante - abre a tela de Busca de Livros
                            new BuscarLivrosGUI().setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "Tipo de usuário desconhecido.");
                        }
                        
                        dispose();  // Fecha a janela de login
                    } else {
                        // Caso as credenciais não sejam válidas
                        JOptionPane.showMessageDialog(null, "Credenciais inválidas. Tente novamente.");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Erro ao autenticar o usuário.");
                }
            }
        });

        
        
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ação de registro (ir para a tela de registro)
                JOptionPane.showMessageDialog(null, "Abrindo tela de registro...");
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ação de voltar à tela inicial
                dispose();  // Fecha a janela de login
                new TelaInicialGUI().setVisible(true); // Abre a tela inicial
            }
        });
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ação de registro (abrir a tela de cadastro)
                new CadastrarUsuarioGUI().setVisible(true);
                dispose();  // Fecha a janela de login
            }
        });
        
        
        // Layout GridBagLayout para organizar os componentes
        gbc.gridx = 0;
        gbc.gridy = 0;
        loginPanel.add(emailLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        loginPanel.add(emailField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        loginPanel.add(senhaLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        loginPanel.add(passwordField, gbc);
        
        // Espaço entre os campos e os botões
        gbc.gridx = 0;
        gbc.gridy = 4;
        loginPanel.add(loginButton, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 5;
        loginPanel.add(registerButton, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 6;
        loginPanel.add(backButton, gbc); // Adicionando o botão de "Voltar"
        
        // Adicionando o painel de login à janela
        add(loginPanel, BorderLayout.CENTER);
    }
    
    private void configurarBotao(JButton botao, Font fonte, Color corFundo, Color corHover) {
        botao.setFont(fonte);
        botao.setBackground(corFundo);
        botao.setForeground(Color.WHITE);
        botao.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        botao.setFocusPainted(false);
        botao.setOpaque(true);
        botao.setPreferredSize(new Dimension(200, 40)); // Aumenta o tamanho do botão
        
        // Efeitos de hover
        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botao.setBackground(corHover);
            }
            
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botao.setBackground(corFundo);
            }
        });
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginGUI().setVisible(true);
            }
        });
    }
}
