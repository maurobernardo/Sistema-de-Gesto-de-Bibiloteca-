package gui;

import model.Usuario;
import dao.UsuarioDAO;
import db.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class CadastrarUsuarioGUI extends JFrame {
    private JTextField nomeField, emailField;
    private JPasswordField senhaField;
    private JComboBox<String> tipoUsuarioCombo;
    private JButton cadastrarButton;
    private UsuarioDAO usuarioDAO;

    public CadastrarUsuarioGUI() {
        try {
            this.usuarioDAO = new UsuarioDAO(DatabaseConnection.getConnection());  // Obter conexão real com o DB
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar com o banco de dados.");
            return;
        }

        setTitle("Cadastro de Usuário - Sistema de Biblioteca");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(245, 245, 245));  // Cor de fundo similar à tela de livros

        // Painel para os campos de entrada com GridBagLayout para centralizar
        JPanel camposPanel = new JPanel();
        camposPanel.setLayout(new GridBagLayout());  // Usando GridBagLayout para centralizar
        camposPanel.setBackground(new Color(245, 245, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);  // Menor espaço entre componentes
        gbc.anchor = GridBagConstraints.WEST;

        // Criando os campos de entrada
        nomeField = new JTextField(20);
        emailField = new JTextField(20);
        senhaField = new JPasswordField(20);
        tipoUsuarioCombo = new JComboBox<>(new String[]{"Funcionario", "Estudante"});

        // Adicionando os rótulos e campos ao painel
        gbc.gridx = 0;
        gbc.gridy = 0;
        camposPanel.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(nomeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        camposPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        camposPanel.add(new JLabel("Senha:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(senhaField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        camposPanel.add(new JLabel("Tipo de Usuário:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(tipoUsuarioCombo, gbc);

        // Painel para o botão de cadastro com FlowLayout para centralizar
        JPanel botoesPanel = new JPanel();
        botoesPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        botoesPanel.setBackground(new Color(245, 245, 245));

        // Botão de cadastro
        cadastrarButton = new JButton("Cadastrar");

        // Estilizando o botão
        configurarBotao(cadastrarButton);

        // Adicionando o botão ao painel de botões
        botoesPanel.add(cadastrarButton);

        // Adicionando os componentes na janela principal
        add(camposPanel, BorderLayout.CENTER);
        add(botoesPanel, BorderLayout.SOUTH);

        // Ação do botão de cadastrar
        cadastrarButton.addActionListener(e -> cadastrarUsuario());

        setLocationRelativeTo(null);  // Centraliza a janela
    }

    // Método para configurar os botões com estilo e efeitos de hover
    private void configurarBotao(JButton botao) {
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setBackground(new Color(0, 122, 204));
        botao.setForeground(Color.WHITE);
        botao.setPreferredSize(new Dimension(140, 35));  // Tamanho compacto
        botao.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        botao.setFocusPainted(false);
        botao.setOpaque(true);

        // Efeito de hover nos botões
        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botao.setBackground(new Color(0, 150, 255));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botao.setBackground(new Color(0, 122, 204));
            }
        });
    }

    private void cadastrarUsuario() {
        String nome = nomeField.getText().trim();
        String email = emailField.getText().trim();
        String senha = new String(senhaField.getPassword()).trim();
        String tipoUsuario = (String) tipoUsuarioCombo.getSelectedItem();

        // Verificar se todos os campos estão preenchidos
        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos!");
            return;  // Não prosseguir com o cadastro
        }

        try {
            Usuario usuario = new Usuario(0, nome, email, senha, tipoUsuario);
            usuarioDAO.cadastrarUsuario(usuario);
            JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!");
            
            // Redireciona para a tela de login após o cadastro
            new LoginGUI().setVisible(true);
            dispose();  // Fecha a janela de cadastro
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar usuário.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CadastrarUsuarioGUI().setVisible(true));
    }
}
