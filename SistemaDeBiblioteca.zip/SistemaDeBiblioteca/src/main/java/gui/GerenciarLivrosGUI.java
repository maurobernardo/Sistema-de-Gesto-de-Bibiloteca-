package gui;

import model.Livro;
import model.Usuario;
import dao.LivroDAO;
import dao.UsuarioDAO;
import db.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class GerenciarLivrosGUI extends JFrame {
    private JTextField tituloField, autorField, anoField, categoriaField, isbnField;
    private JButton cadastrarButton, editarButton, removerButton, listarButton, listarUsuariosButton, voltarButton;
    private LivroDAO livroDAO;

    public GerenciarLivrosGUI() {
        try {
            this.livroDAO = new LivroDAO(DatabaseConnection.getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro na conexão com o banco de dados.");
            return;
        }

        setTitle("Gerenciar Livros - Sistema de Biblioteca");
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(245, 245, 245));

        // Painel para os campos de entrada com GridBagLayout para centralizar
        JPanel camposPanel = new JPanel();
        camposPanel.setLayout(new GridBagLayout());  // Usando GridBagLayout para centralizar
        camposPanel.setBackground(new Color(245, 245, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);  // Menor espaço entre componentes
        gbc.anchor = GridBagConstraints.WEST;

        // Criando os campos de entrada
        tituloField = new JTextField(20);
        autorField = new JTextField(20);
        anoField = new JTextField(6);
        categoriaField = new JTextField(8);
        isbnField = new JTextField(8);

        // Adicionando os rótulos e campos ao painel
        gbc.gridx = 0;
        gbc.gridy = 0;
        camposPanel.add(new JLabel("Título:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(tituloField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        camposPanel.add(new JLabel("Autor:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(autorField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        camposPanel.add(new JLabel("Ano:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(anoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        camposPanel.add(new JLabel("Categoria:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(categoriaField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        camposPanel.add(new JLabel("ISBN:"), gbc);
        gbc.gridx = 1;
        camposPanel.add(isbnField, gbc);

        // Painel para os botões com FlowLayout para centralizar na horizontal
        JPanel botoesPanel = new JPanel();
        botoesPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));  // FlowLayout com centralização
        botoesPanel.setBackground(new Color(245, 245, 245));

        // Botões de ação com tamanhos reduzidos
        cadastrarButton = new JButton("Cadastrar Livro");
        editarButton = new JButton("Editar Livro");
        removerButton = new JButton("Remover Livro");
        listarButton = new JButton("Listar Livros");
        listarUsuariosButton = new JButton("Listar Usuários");
        voltarButton = new JButton("Voltar");

        // Estilizando os botões
        configurarBotao(cadastrarButton);
        configurarBotao(editarButton);
        configurarBotao(removerButton);
        configurarBotao(listarButton);
        configurarBotao(listarUsuariosButton);
        configurarBotao(voltarButton); // Configurando o botão Voltar

        // Adicionando os botões ao painel de botões
        botoesPanel.add(cadastrarButton);
        botoesPanel.add(editarButton);
        botoesPanel.add(removerButton);
        botoesPanel.add(listarButton);
        botoesPanel.add(listarUsuariosButton);
        botoesPanel.add(voltarButton); // Adicionando o botão Voltar

        // Adicionando componentes na janela principal
        add(camposPanel, BorderLayout.CENTER);  // Centraliza o painel de campos
        add(botoesPanel, BorderLayout.SOUTH);  // Coloca os botões na parte inferior

        // Ações dos botões
        cadastrarButton.addActionListener(e -> cadastrarLivro());
        editarButton.addActionListener(e -> editarLivro());
        removerButton.addActionListener(e -> removerLivro());
        listarButton.addActionListener(e -> listarLivros());
        listarUsuariosButton.addActionListener(e -> listarUsuarios());
        voltarButton.addActionListener(e -> voltarTelaLogin());  // Ação do botão Voltar

        setLocationRelativeTo(null);  // Centraliza a janela
    }

    private void configurarBotao(JButton botao) {
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setBackground(new Color(0, 122, 204));
        botao.setForeground(Color.WHITE);
        botao.setPreferredSize(new Dimension(140, 35));  // Tamanho compacto
        botao.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        botao.setFocusPainted(false);
        botao.setOpaque(true);

        // Efeito de hover nos botões
        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botao.setBackground(new Color(0, 150, 255));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botao.setBackground(new Color(0, 122, 204));
            }
        });
    }

    private void cadastrarLivro() {
        try {
            Livro livro = new Livro(0, tituloField.getText(), autorField.getText(),
                    Integer.parseInt(anoField.getText()), categoriaField.getText(), isbnField.getText());
            livroDAO.cadastrarLivro(livro);
            JOptionPane.showMessageDialog(null, "Livro cadastrado com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar livro.");
        }
    }

    private void editarLivro() {
        String idInput = JOptionPane.showInputDialog("Digite o ID do livro para editar:");
    
        if (idInput != null && !idInput.isEmpty()) {
            try {
                int idLivro = Integer.parseInt(idInput); // Converte o ID para inteiro
    
                // Busca o livro pelo ID no banco de dados
                Livro livroExistente = livroDAO.buscarLivroPorId(idLivro);
                if (livroExistente == null) {
                    JOptionPane.showMessageDialog(null, "Livro com ID " + idLivro + " não encontrado.");
                    return;
                }
    
                // Preenche os campos de texto com os dados do livro encontrado
                tituloField.setText(livroExistente.getTitulo());
                autorField.setText(livroExistente.getAutor());
                anoField.setText(String.valueOf(livroExistente.getAnoPublicacao()));
                categoriaField.setText(livroExistente.getCategoria());
                isbnField.setText(livroExistente.getIsbn());
    
                // Exibe uma nova janela para que o usuário edite os campos
                JPanel editPanel = new JPanel(new GridLayout(5, 2));
                editPanel.add(new JLabel("Novo Título:"));
                JTextField novoTituloField = new JTextField(livroExistente.getTitulo());
                editPanel.add(novoTituloField);
    
                editPanel.add(new JLabel("Novo Autor:"));
                JTextField novoAutorField = new JTextField(livroExistente.getAutor());
                editPanel.add(novoAutorField);
    
                editPanel.add(new JLabel("Novo Ano:"));
                JTextField novoAnoField = new JTextField(String.valueOf(livroExistente.getAnoPublicacao()));
                editPanel.add(novoAnoField);
    
                editPanel.add(new JLabel("Nova Categoria:"));
                JTextField novaCategoriaField = new JTextField(livroExistente.getCategoria());
                editPanel.add(novaCategoriaField);
    
                editPanel.add(new JLabel("Novo ISBN:"));
                JTextField novoIsbnField = new JTextField(livroExistente.getIsbn());
                editPanel.add(novoIsbnField);
    
                int confirmarEdicao = JOptionPane.showConfirmDialog(null, editPanel, 
                                                                    "Editar Livro", JOptionPane.OK_CANCEL_OPTION);
    
                if (confirmarEdicao == JOptionPane.OK_OPTION) {
                    // Obter os novos valores dos campos
                    String novoTitulo = novoTituloField.getText();
                    String novoAutor = novoAutorField.getText();
                    int novoAno = Integer.parseInt(novoAnoField.getText());
                    String novaCategoria = novaCategoriaField.getText();
                    String novoIsbn = novoIsbnField.getText();
    
                    // Cria o objeto livro com as atualizações feitas nos campos
                    Livro livroAtualizado = new Livro(idLivro, novoTitulo, novoAutor, novoAno, novaCategoria, novoIsbn);
    
                    // Atualiza o livro no banco de dados
                    livroDAO.editarLivro(livroAtualizado);
                    JOptionPane.showMessageDialog(null, "Livro editado com sucesso!");
                }
    
            } catch (NumberFormatException e) {
                // Caso o ID ou o ano não seja um número válido
                JOptionPane.showMessageDialog(null, "ID ou Ano inválido. Por favor, insira um número válido.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro ao editar livro.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "ID do livro não pode ser vazio.");
        }
    }
    
    
    private void removerLivro() {
        try {
            int idLivro = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID do livro para remover:"));
            livroDAO.removerLivro(idLivro);
            JOptionPane.showMessageDialog(null, "Livro removido com sucesso!");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao remover livro.");
        }
    }

    private void listarLivros() {
        try {
            List<Livro> livros = livroDAO.listarLivros();
            StringBuilder livrosDetalhados = new StringBuilder("Lista de Livros:\n");

            for (Livro livro : livros) {
                livrosDetalhados.append("ID: ").append(livro.getId())
                        .append(" | Título: ").append(livro.getTitulo())
                        .append(" | Autor: ").append(livro.getAutor())
                        .append(" | Ano: ").append(livro.getAnoPublicacao())
                        .append(" | Categoria: ").append(livro.getCategoria())
                        .append(" | ISBN: ").append(livro.getIsbn())
                        .append("\n");
            }

            JOptionPane.showMessageDialog(null, livrosDetalhados.toString(), "Livros Cadastrados", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao listar livros.");
        }
    }

    private void listarUsuarios() {
        try {
            UsuarioDAO usuarioDAO = new UsuarioDAO(DatabaseConnection.getConnection());
            List<Usuario> usuarios = usuarioDAO.listarUsuarios();
            StringBuilder usuariosDetalhados = new StringBuilder("Lista de Usuários:\n");

            for (Usuario usuario : usuarios) {
                usuariosDetalhados.append("ID: ").append(usuario.getId())
                        .append(" | Nome: ").append(usuario.getNome())
                        .append(" | Email: ").append(usuario.getEmail())
                        .append("\n");
            }

            JOptionPane.showMessageDialog(null, usuariosDetalhados.toString(), "Usuários Cadastrados", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao listar usuários.");
        }
    }

    private void voltarTelaLogin() {
        // Fechar a tela atual e abrir a tela de login
        this.dispose();
        new LoginGUI().setVisible(true);  // Supondo que sua tela de login se chama TelaLoginGUI
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GerenciarLivrosGUI().setVisible(true));
    }
}
