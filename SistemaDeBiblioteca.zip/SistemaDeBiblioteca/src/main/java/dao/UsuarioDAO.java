package dao;

import model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import db.DatabaseConnection;

public class UsuarioDAO {
    private Connection connection;

    // Construtor com a obtenção da conexão
    public UsuarioDAO(Connection connection1) {
        try {
            this.connection = DatabaseConnection.getConnection();  // Obtém a conexão do banco
        } catch (SQLException e) {
            System.out.println("Erro na Conexao Com a Base de Dados");
        }
    }

    // Método para adicionar um novo usuário
    public void cadastrarUsuario(Usuario usuario) throws SQLException {
        String query = "INSERT INTO usuarios (nome, email, senha, tipo_usuario) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getSenha());
            stmt.setString(4, usuario.getTipoUsuario());
            stmt.executeUpdate();  // Executa o comando de inserção
        } catch (SQLException e) {
            System.out.println("Todos os campos devem ser preechidos com dados validos");
            throw new SQLException("Erro ao cadastrar usuário", e);
        }
    }
    

    // Método para autenticar um usuário (login)
    public Usuario autenticarUsuario(String email, String senha) throws SQLException {
        String query = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, email);
            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                // Se encontrar o usuário, retorna o objeto Usuario
                return new Usuario(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("senha"),
                    rs.getString("tipo_usuario")
                );
            }
        } catch (SQLException e) {
            System.out.println("O Email e senha devem ser validos");
            throw new SQLException("Erro ao autenticar o usuário", e);
        }
        return null; // Retorna null se não encontrar o usuário
    }

    // Método para listar todos os usuários (para funcionários)
    public List<Usuario> listarUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String query = "SELECT * FROM usuarios";
        
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                usuarios.add(new Usuario(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("senha"),
                    rs.getString("tipo_usuario")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao listar os usuários", e);
        }
        return usuarios;
    }

    // Método para verificar se um usuário já existe pelo email
    public boolean usuarioExiste(String email) throws SQLException {
        String query = "SELECT * FROM usuarios WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            return rs.next();  // Se encontrar algum registro, retorna true
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao verificar a existência do usuário", e);
        }
    }

    // Método para atualizar os dados de um usuário
    public void atualizarUsuario(Usuario usuario) throws SQLException {
        String query = "UPDATE usuarios SET nome = ?, email = ?, senha = ?, tipo_usuario = ? WHERE id = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getSenha());
            stmt.setString(4, usuario.getTipoUsuario());
            stmt.setInt(5, usuario.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao atualizar os dados do usuário", e);
        }
    }

    // Método para excluir um usuário
    public void excluirUsuario(int usuarioId) throws SQLException {
        String query = "DELETE FROM usuarios WHERE id = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, usuarioId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao excluir o usuário", e);
        }
    }
}
