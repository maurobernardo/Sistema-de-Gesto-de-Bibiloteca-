package dao;

import db.DatabaseConnection;
import model.Categoria;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {
    private Connection connection;

    // Construtor que obtém a conexão usando a classe DatabaseConnection
    public CategoriaDAO() {
         try {
            this.connection = DatabaseConnection.getConnection();  // Obtém a conexão do banco
        } catch (SQLException e) {
            System.out.println("Erro na Conexao Com a Base de Dados");
        }  // Obtém a conexão usando DatabaseConnection
    }

    // Método para adicionar uma categoria
    public void cadastrarCategoria(Categoria categoria) throws SQLException {
        String query = "INSERT INTO categorias (nome, descricao) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, categoria.getNome());
            stmt.setString(2, categoria.getDescricao());
            stmt.executeUpdate();
        }
    }

    // Método para listar todas as categorias
    public List<Categoria> listarCategorias() throws SQLException {
        List<Categoria> categorias = new ArrayList<>();
        String query = "SELECT * FROM categorias";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                categorias.add(new Categoria(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("descricao")
                ));
            }
        }
        return categorias;
    }
}
