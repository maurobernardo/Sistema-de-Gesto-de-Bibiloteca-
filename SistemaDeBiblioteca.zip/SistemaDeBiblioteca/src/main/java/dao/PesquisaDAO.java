package dao;

import model.Pesquisa;
import model.Livro;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import db.DatabaseConnection;

public class PesquisaDAO {
    private Connection connection;

    // Construtor com a conexão ao banco de dados
    public PesquisaDAO()  {
        try {
            this.connection = DatabaseConnection.getConnection();  // Obtém a conexão do banco
        } catch (SQLException e) {
            System.out.println("Erro na Conexao Com a Base de Dados");
        }  
    }

    // Método para pesquisar livros com base no termo de busca
    public List<Livro> pesquisarLivros(Pesquisa pesquisa) throws SQLException {
        List<Livro> livros = new ArrayList<>();
        String query = "SELECT * FROM livros WHERE titulo LIKE ? OR autor LIKE ? OR categoria LIKE ?";

        // Usando try-with-resources para garantir o fechamento da conexão e do Statement
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            String termo = "%" + pesquisa.getTermoBusca() + "%";
            stmt.setString(1, termo);
            stmt.setString(2, termo);
            stmt.setString(3, termo);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    livros.add(new Livro(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        rs.getString("autor"),
                        rs.getInt("ano_publicacao"),
                        rs.getString("categoria"),
                        rs.getString("isbn")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao realizar a pesquisa de livros", e);
        }
        return livros;
    }
}
