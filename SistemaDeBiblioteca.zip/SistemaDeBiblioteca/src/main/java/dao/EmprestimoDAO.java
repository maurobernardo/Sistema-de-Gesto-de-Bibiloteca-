package dao;

import db.DatabaseConnection;
import model.Emprestimo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmprestimoDAO {
    private Connection connection;

    
    public EmprestimoDAO() throws SQLException {
         try {
            this.connection = DatabaseConnection.getConnection();  // Obtém a conexão do banco
        } catch (SQLException e) {
            System.out.println("Erro na Conexao Com a Base de Dados");
        } 
    }

    // Método para registrar um empréstimo
    public void registrarEmprestimo(Emprestimo emprestimo) throws SQLException {
        String query = "INSERT INTO emprestimos (id_livro, id_usuario, data_emprestimo, data_devolucao) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, emprestimo.getIdLivro());
            stmt.setInt(2, emprestimo.getIdUsuario());
            stmt.setDate(3, new Date(emprestimo.getDataEmprestimo().getTime()));
            stmt.setDate(4, new Date(emprestimo.getDataDevolucao().getTime()));
            stmt.executeUpdate();
        }
    }

    // Método para listar todos os empréstimos
    public List<Emprestimo> listarEmprestimos() throws SQLException {
        List<Emprestimo> emprestimos = new ArrayList<>();
        String query = "SELECT * FROM emprestimos";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                emprestimos.add(new Emprestimo(
                    rs.getInt("id"),
                    rs.getInt("id_livro"),
                    rs.getInt("id_usuario"),
                    rs.getDate("data_emprestimo"),
                    rs.getDate("data_devolucao")
                ));
            }
        }
        return emprestimos;
    }

    // Método para verificar se um livro está emprestado
    public boolean verificarLivroEmprestado(int idLivro) throws SQLException {
        String query = "SELECT * FROM emprestimos WHERE id_livro = ? AND data_devolucao IS NULL";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, idLivro);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Retorna true se o livro estiver emprestado
        }
    }
}
