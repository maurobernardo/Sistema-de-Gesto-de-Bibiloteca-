package dao;

import db.DatabaseConnection;
import model.Livro;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivroDAO {
    private Connection connection;

    // Construtor que obtém a conexão usando a classe DatabaseConnection
    public LivroDAO(Connection connection1) {
        try {
            this.connection = DatabaseConnection.getConnection(); // Obtém a conexão do banco
        } catch (SQLException e) {
            System.out.println("Erro na Conexao Com a Base de Dados");
        } 
    }

    // Método para cadastrar um novo livro
    public void cadastrarLivro(Livro livro) throws SQLException {
        String query = "INSERT INTO livros (titulo, autor, ano_publicacao, categoria, isbn) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, livro.getTitulo());
            stmt.setString(2, livro.getAutor());
            stmt.setInt(3, livro.getAnoPublicacao());
            stmt.setString(4, livro.getCategoria());
            stmt.setString(5, livro.getIsbn());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Todos os campos devem ser preechidos com dados validos");
            throw new SQLException("Erro ao cadastrar Livro", e);
        }
    }

    // Método para editar as informações de um livro
    public void editarLivro(Livro livro) throws SQLException {

        String query = "UPDATE livros SET titulo = ?, autor = ?, ano_publicacao = ?, categoria = ?, isbn = ? WHERE id = ?";

        // Verificação de dados antes de executar a atualização
        if (livro == null || livro.getId() <= 0) {
            throw new IllegalArgumentException("O livro ou o ID do livro não pode ser nulo ou inválido.");
        }

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            // Configura os parâmetros no PreparedStatement
            stmt.setString(1, livro.getTitulo()); // Título do livro
            stmt.setString(2, livro.getAutor()); // Autor do livro
            stmt.setInt(3, livro.getAnoPublicacao()); // Ano de publicação
            stmt.setString(4, livro.getCategoria()); // Categoria do livro
            stmt.setString(5, livro.getIsbn()); // ISBN do livro
            stmt.setInt(6, livro.getId()); // ID do livro

            // Executa a atualização no banco de dados
            int rowsAffected = stmt.executeUpdate();

            // Verifica se a atualização foi bem-sucedida
            if (rowsAffected == 0) {
                throw new SQLException("Nenhum livro foi atualizado, o ID pode ser inválido.");
            }

            System.out.println("Livro atualizado com sucesso!"); // Log para depuração

        } catch (SQLException ex) {
            // Manipulação de exceções de SQL (erro na execução da query)
            System.err.println("Erro ao tentar atualizar o livro: " + ex.getMessage());
            throw ex; // Re-lança a exceção para ser tratada em outro ponto, se necessário
        } catch (Exception ex) {

            System.err.println("Erro inesperado ao atualizar o livro: " + ex.getMessage());
            throw new SQLException("Erro inesperado ao tentar atualizar o livro.", ex);
        }
    }

    // Método para remover um livro do acervo
    public void removerLivro(int id) throws SQLException {
        String query = "DELETE FROM livros WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    // Método para buscar livros por título, autor ou categoria
    public List<Livro> buscarLivros(String termo) throws SQLException {
        List<Livro> livros = new ArrayList<>();
        String query = "SELECT * FROM livros WHERE titulo LIKE ? OR autor LIKE ? OR categoria LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            String termoBusca = "%" + termo + "%";
            stmt.setString(1, termoBusca);
            stmt.setString(2, termoBusca);
            stmt.setString(3, termoBusca);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    livros.add(new Livro(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            rs.getString("autor"),
                            rs.getInt("ano_publicacao"),
                            rs.getString("categoria"),
                            rs.getString("isbn")));
                }
            }
        }
        return livros;
    }

    // Método para buscar um livro pelo ID
    public Livro buscarLivroPorId(int id) throws SQLException {
        String query = "SELECT * FROM livros WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id); // Define o parâmetro da consulta para o ID do livro
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) { // Se o livro com o ID fornecido for encontrado
                    return new Livro(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            rs.getString("autor"),
                            rs.getInt("ano_publicacao"),
                            rs.getString("categoria"),
                            rs.getString("isbn"));
                }
            }
        }
        return null; // Retorna null se não encontrar o livro com o ID fornecido
    }

    // Método para listar todos os livros
    public List<Livro> listarLivros() throws SQLException {
        List<Livro> livros = new ArrayList<>();
        String query = "SELECT * FROM livros";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                livros.add(new Livro(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        rs.getString("autor"),
                        rs.getInt("ano_publicacao"),
                        rs.getString("categoria"),
                        rs.getString("isbn")));
            }
        }
        return livros;
    }
}
